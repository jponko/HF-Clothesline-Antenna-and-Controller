#!/bin/bash -v
    kikit panelize \
        --layout 'grid; rows: 1; cols: 2; space: 2mm' \
        --tabs 'fixed; hwidth: 10mm; vwidth: 10mm' \
        --cuts vcuts \
        --post 'millradius: 1mm' \
        detector.kicad_pcb panel.kicad_pcb

